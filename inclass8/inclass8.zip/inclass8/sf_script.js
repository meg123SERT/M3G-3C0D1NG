/*  JavaScript 6th Edition
	Chapter 2
	In-Class Activity

	Author: 
	Date:   
	
	Filename: sf_script.js
*/

